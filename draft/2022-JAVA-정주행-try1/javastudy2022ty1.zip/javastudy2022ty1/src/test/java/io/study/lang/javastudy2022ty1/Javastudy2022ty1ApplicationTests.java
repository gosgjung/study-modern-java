package io.study.lang.javastudy2022ty1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Javastudy2022ty1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
