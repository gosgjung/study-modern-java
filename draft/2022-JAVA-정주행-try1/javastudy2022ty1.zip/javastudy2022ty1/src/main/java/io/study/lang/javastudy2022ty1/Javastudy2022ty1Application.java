package io.study.lang.javastudy2022ty1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Javastudy2022ty1Application {

	public static void main(String[] args) {
		SpringApplication.run(Javastudy2022ty1Application.class, args);
	}

}
